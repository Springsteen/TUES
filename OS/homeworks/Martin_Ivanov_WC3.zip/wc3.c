//--------------------------------------------
// NAME: Martin Ivanov
// CLASS: 11B
// NUMBER: 19
// PROBLEM: #3
// FILE NAME: wc3.c 
// FILE PURPOSE: 
// simulating WarCraft3
// mine digging with
// N mines and M workers
//---------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

pthread_mutex_t* mutexes;
pthread_mutex_t gold_mutex;
int* w_arr;
int* m_arr;
int* flags;
int gold_left;
int mine_capacity;
int mines;
int workers; 

//--------------------------------------------
// FUNCTION: dig
// Digging simulation 
// PARAMETERS:
// void* arg - the id of the worker
//----------------------------------------------

void* dig(void* arg){
	int k,a;
	long int id = (long int) arg;

	search:
		for (k = 0; k < mines; ++k){
			pthread_mutex_lock(&mutexes[k]);
				if((flags[k] == 0) && (m_arr[k] >= 10)){ // if the mine is free and isn't empty - start digging
					printf("Worker %ld entered mine %d\n", id+1, k+1 );
					sleep(1);
					flags[k] = 1;
					m_arr[k]-=10;
					w_arr[id]+=10;
					
					pthread_mutex_lock(&gold_mutex);
						gold_left -= 10; 
						/* because this variable is global 
						we must protect it with mutex
						to avoid unwanted behaviour
						*/
					pthread_mutex_unlock(&gold_mutex);

					printf("Worker %ld exited mine %d\n", id+1, k+1 );
				}
				flags[k] = 0;
			pthread_mutex_unlock(&mutexes[k]);
		}

	if( gold_left > 0) {
		for(a=0; a < mines; ++a){
			if(m_arr[a]>=10){
				// if you set value which is not dividable by 10, the result of the 
				//gold_in_mines % 10 will not be digged because a worker can only dig 10 gold
				goto search; // if there is 10 gold in any mine go to the begining
			}
		}
	}

	return NULL; 
}
//--------------------------------------------
// argv[1] - the capacity of the mines  
// argv[2] - how many workers
// argv[3] - how many mines
//----------------------------------------------

int main(int argc, char* argv[]) {
	
	if ( argc < 4 ) {
		printf("Not enough arguments!\n");
		printf("Setting default values\n");
		sleep(3);
		mine_capacity = 100;
		workers = 2;  
		mines = 1;		
	}else{

		mine_capacity = atoi(argv[1]);
		workers = atoi(argv[2]);  
		mines = atoi(argv[3]);

		if ( (mine_capacity < 1) || (workers < 1) || (mines < 1) ) {
			printf("Bad input values !\n");
			return -2;
		}
	}
		
	w_arr = calloc(workers, sizeof(int));
	m_arr = calloc(mines, sizeof(int));
	mutexes = calloc(mines, sizeof(pthread_mutex_t));
	flags = calloc(mines, sizeof(int));
	
	if(pthread_mutex_init(&gold_mutex, NULL) != 0){
		printf("Initializing gold_mutex failed\n");
		return -7;
	}

	int i;
	for (i = 0; i < mines; ++i)	{
		m_arr[i] = mine_capacity;
		flags[i] = 0;
		if(pthread_mutex_init(&mutexes[i], NULL) != 0){
			printf("Initializing mutex number %d failed\n",i);
			return -3;
		}
	}
	gold_left = mines*mine_capacity;

	pthread_t threads[workers];

	for(i=0; i<workers; ++i){
		if(pthread_create(&threads[i], NULL, dig, (void *) (intptr_t) i) != 0) {
			printf("Creating thread number %d failed\n",i);
			return -4;
		}
	}
	
	for(i=0; i<workers; ++i){
		if(pthread_join(threads[i], NULL) != 0){
			printf("Joining thread number %d failed\n",i);
			return -5;
		}
	}

	int total_gold_digged = 0;
	for(i=0; i<workers; ++i){
		total_gold_digged += w_arr[i];
		printf("Worker %d digged %d from the mines\n", i+1, w_arr[i]);
	}
	printf("All gold %d, gold collected %d\n",mines*mine_capacity, total_gold_digged );

	for(i=0; i<mines; ++i){
		if(pthread_mutex_destroy(&mutexes[i]) != 0){
			printf("Destroing mutex number %d failed\n",i);
			return -6;
		}
	}

	if(pthread_mutex_destroy(&gold_mutex) != 0){
		printf("Destroing gold mutex failed\n");
		return -8;
	}

	free(w_arr);
	free(m_arr);
	free(mutexes);
	
	return 0;
} 