#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

int flags[3] = { 0, 0, 0 }; //0 -l  1 -R  2 -a

int is_file (char *name);
/* checks weather the given string is a file in the
	working directory or not */

void list_dir_content (char *dir_name);
/* prints the ls output according to the given flags */

int compare_string (char *first, char *second);
/* compares two strings byte by byte */

void get_flags (int argc,char *argv[]);
/* checks a string for containing 
   'l', 'R' or 'a'*/

int main(int argc, char *argv[]){
		printf("\n");
	int i;
	get_flags(argc,argv);
	
	if(argc == 1){
		list_dir_content(".");
	}else if((argc == 2) && (argv[1][0] == '-')){
		list_dir_content(".");
	}else{	
		for (i=1; i < argc; ++i){
			// if the argument is not a flag
			// work with it
			if ((argv[i][0] != '-')){
				// if the argument is not a file
				// in the current dir
				// work with it
				if(is_file(argv[i]) == 0){					
					printf("%s\n",argv[i]);
					list_dir_content(argv[i]);
					printf("\n");
				}else{
					printf("%s\n",argv[i]);
					printf("\n\n");
				}
			}
		}
	}

	return 0;
}

void list_dir_content (char* dir_name){
	DIR *dp;
	struct dirent *ep;
	dp = opendir (dir_name);
	
	if (dp != NULL){
		while (ep = readdir (dp)){
			// if the file is hidden and 
			// the -a flag is not 1 
			// skip this file
			if ((ep->d_name[0]== '.') && (flags[2] == 0)) {
				continue;
			}

			// if the -l flag is 1 give details
			if (flags[0] == 1){
				struct stat fstat;
				stat(ep->d_name, &fstat);
				printf((S_ISDIR(fstat.st_mode)) ? "d" : "-");
				printf((fstat.st_mode & S_IRUSR) ? "r" : "-");
				printf((fstat.st_mode & S_IWUSR) ? "w" : "-");
				printf((fstat.st_mode & S_IXUSR) ? "x" : "-");
				printf((fstat.st_mode & S_IRGRP) ? "r" : "-");
				printf((fstat.st_mode & S_IWGRP) ? "w" : "-");
				printf((fstat.st_mode & S_IXGRP) ? "x" : "-");
				printf((fstat.st_mode & S_IROTH) ? "r" : "-");
				printf((fstat.st_mode & S_IWOTH) ? "w" : "-");
				printf((fstat.st_mode & S_IXOTH) ? "x" : "-");	
				// prints the number of links to this file
				printf(" %d", (int) fstat.st_nlink);
				// prints the owner name
				printf(" %s", getpwuid(fstat.st_uid)->pw_name);
				// prints the group name
				printf(" %s", getgrgid(fstat.st_gid)->gr_name);
				// prints the number of block used by this file
				printf(" %5d", (int) fstat.st_size);
				// prints the time of last modification
				char mtime[20];
				strftime(mtime, 20,"%b  %d %R", localtime(&fstat.st_mtime));	
				printf(" %s", mtime);		
				printf("   %s\n",ep->d_name);
			}else{
				printf("%s\n",ep->d_name);
			}
		}	

		int out;
		// closedir returns 0 on success so
		// we close until we get 0 
		do {
			out = closedir (dp);
		}while(out != 0);
	}else{
		perror ("Couldn’t open the directory");
	}
}

void get_flags (int argc, char *argv[]){
	char c;
	while ((c = getopt (argc, argv, "lRa")) != -1)
        switch (c){
           	case 'l':
             	flags[0] = 1;
             	break;
           	case 'R':
             	flags[1] = 1;
           		break;
           	case 'a':
             	flags[2] = 1;
             	break;
        }
}

int is_file(char* name){
	DIR *dp;
	struct dirent *ep;
	dp = opendir (".");

	struct stat fstat;
	stat(name, &fstat);
	
	if (dp != NULL){
		while (ep = readdir (dp)){
			if ((compare_string(name, ep->d_name) == 0) && 
				(S_ISDIR(fstat.st_mode) == 0) ){
				return 1;
			}
		}	
		int out;
		// closedir returns 0 on success so
		// we close until we get 0 
		do {
			out = closedir (dp);
		}while(out != 0);
	}

	return 0;
}

int compare_string(char *first, char *second){
   while(*first==*second){
      	if ( *first == '\0' || *second == '\0' )
        	break;
 
      	first++;
      	second++;
   	}
   	
   	if( *first == '\0' && *second == '\0' )
    	return 0;
   	else
      	return -1;
}
