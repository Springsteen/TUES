//--------------------------------------------
// NAME: Martin Ivanov
// CLASS: 11B
// NUMBER: 19
// PROBLEM: #2
// FILE NAME: shell.c
// FILE PURPOSE: A simple shell implementation
//---------------------------------------------

#include <stdlib.h> 
#include <string.h> 
#include <stdio.h>

//---------------------------------------------
// NAME: find_spaces
// ARGUMENTS: char* 
// PURPOSE: takes a string a counts the spaces
// *NOTE - if there are many spaces between 2
// words, they'll be counted for one
//---------------------------------------------

int find_spaces(char* cmdline){
	int i;
	int boolean = 1;
	int spaces = 0;

	for(i = 0; i < strlen(cmdline); i++) {
   		if (((cmdline[i] == ' ') || (cmdline[i] == '\t')) || (cmdline[i] == '\n')) {
            if (boolean == 0) {
                spaces++ ;        
            }                                
            boolean = 1 ;
        } else {
            if (boolean == 1 ) {
                boolean = 0 ;
            }
        }        
  	}

  	return spaces;
}

//---------------------------------------------
// NAME: parse_cmdline
// ARGUMENTS: const char* cmdline 
// PURPOSE: takes the input from the stdin and 
// divides it by spaces 
//---------------------------------------------
int spaces; // It needs to be global so we can 
			// free the memory correctly
char** parse_cmdline(char* cmdline){

	spaces = find_spaces(cmdline);
	printf("%d\n",spaces );
	char** arguments = (char**)malloc((spaces+2) * (sizeof(char*)));
    int arg_num = 0;

    char* tmp = strtok(cmdline, "\n");
	tmp = strtok(tmp, " ");

	while(tmp != NULL){
		arguments[arg_num] = malloc(strlen(tmp)+1);
		strcpy(arguments[arg_num++],tmp) ;
		tmp = strtok(NULL, " ");
	}

	arguments[arg_num] = '\0';

	return arguments;
}

//---------------------------------------------
// NAME: free_memory
// ARGUMENTS: char** 
// PURPOSE: free two dimensional arrays
//---------------------------------------------

void free_memory(char** array){
	int i;
    for(i = 0; i < spaces+2; i++)
        free(array[i]);
    free(array);
}

int main(int argc, char** argv) {
        
	while(1){

        char** arguments ;

	    short int i=0 ;
	    char *buffer = NULL , ch ;
	    buffer=malloc(1) ;

	    while ((ch=fgetc(stdin)) != '\n') {
	    	if ( ch == EOF ) return 0 ;
	    	// reading user input until pressing ENTER
	        buffer[i]=ch ;
	        buffer=realloc(buffer,i+2) ;
	        // writing the next byte from the user's input and allocating spacr for one more
	        i++ ;
	    }
	    buffer[i]='\0'; // terminating the string

		arguments = parse_cmdline(buffer) ;

		pid_t process ;

		if((process = fork()) == -1){
			// if problem occures forking the process 
			fprintf(stderr,"%s\n","shell:Problem with fork") ;
			exit(EXIT_FAILURE) ;
		}else if (process == 0){
			// if the the fork() function worked corectly we
			// will run the command given from stdin with its arguments
			pid_t exec_status = execv(arguments[0],arguments) ;

			if (exec_status == -1) {
				// if problem occures executing the command
				fprintf(stderr, "%s\n","shell:Problem with execv" ) ;
				exit(EXIT_FAILURE) ;
			}else{
				exit(EXIT_SUCCESS);
			}
		}else {
			// if the child doesn't give a result equal to 0 or -1
			// we wait it to complete itself
			pid_t wait_status ; 
			waitpid(process,&wait_status,0) ;
		}

		free_memory(arguments);
		free(buffer);
	}

}


